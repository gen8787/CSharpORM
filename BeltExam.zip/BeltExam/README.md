Login and Registration with Validations
    [x] Validation messages should display for unsuccessful submissions
    [x] (Registration) Password with a minimum length of 8 characters
    [x] (Registration) Name with a minimum length of 2 characters
    [x] (Registration) Valid Email Address
    [x] (Registration) No duplicate Emails
    [x] (Login) Valid Email and Password
Dashboard
    [x] Activities should be displayed in order of date/time with the most recent at the top.
    [x] Ability to join or leave an activity.
    [x] Ability to delete an activity if the logged user created it.
    [x] Activity name redirects to the Activity page.
    [x] Add New Activity button redirects to New Activity page.
Activity Details
    [x] Ability to Join or Leave activity based on the current logged user.
    [x] Can Delete activity if the logged user created it.
    [x] List all other users participating in the activity.
    [x] PROFICIENCY RELATED FEATURES NOT REQUIRED FOR A RED BELT
New Activity
    [x] Activity Date must be in the future
    [x] Title and description are required fields